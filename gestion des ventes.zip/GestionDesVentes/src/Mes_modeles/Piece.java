/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mes_modeles;

/**
 *
 */
public class Piece{
    
    public String Nom_Commercial;
    public String N_Lot;
    public String Qte;
    public String PrixAchat;
    public String SHP;
    public String TotalAchat ;
    public String Code_Barre;
    public String tva;

    public Piece(String Nom_Commercial,String N_Lot,String Qte,String PrixAchat,String SHP,String TotalAchat,String Code_Barre,String tva)
      {
        
        this.Nom_Commercial = Nom_Commercial;
        this.N_Lot = N_Lot;
        this.Qte = Qte;
        this.PrixAchat = PrixAchat;
        this.SHP = SHP;
        this.TotalAchat= TotalAchat;
        this.Code_Barre = Code_Barre;
        this.tva= tva;
  
}
}
