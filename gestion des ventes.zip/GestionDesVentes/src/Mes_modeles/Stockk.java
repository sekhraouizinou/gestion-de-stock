/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mes_modeles;

/**
 *
 * @author Benarroudj
 */
public class Stockk {

    int N_prod;
    String Nom_Commercial;
    String date_ach;
    int stock;
    int qte_vente;
    int qte_reste;
    float Prix_Vente;
    float Prix_Achat;
    float gain;

    public Stockk(int N_prod, String Nom_Commercial, String date_ach, int stock, int qte_vente,  float Prix_Vente, float Prix_Achat) {
        this.N_prod = N_prod;
        this.Nom_Commercial = Nom_Commercial;
        this.date_ach = date_ach;
        this.stock = stock;
        this.qte_vente = qte_vente;
        this.qte_reste = this.stock-this.qte_vente;
        this.Prix_Vente = Prix_Vente;
        this.Prix_Achat = Prix_Achat;
        this.gain = this.Prix_Vente-this.Prix_Achat;
    }
    public Stockk(int N_prod, String Nom_Commercial, int stock, int qte_vente, float Prix_Vent, float gain) {
        this.N_prod = N_prod;
        this.Nom_Commercial = Nom_Commercial;
        this.stock = stock;
        this.qte_vente = qte_vente;
        this.Prix_Vente = Prix_Vent;
        this.gain = gain;
    }

    public Stockk(int N_prod, String Nom_Commercial, int stock, int qte_vente, int qte_reste,float Prix_Vent, float gain) {
        this.N_prod = N_prod;
        this.Nom_Commercial = Nom_Commercial;
        this.stock = stock;
        this.qte_vente = qte_vente;
        this.qte_reste = qte_reste;
        this.Prix_Vente = Prix_Vent;
        this.gain = gain;
    }


    public int getN_prod() {
        return N_prod;
    }

    public String getNom_Commercial() {
        return Nom_Commercial;
    }

    public String getDate_ach() {
        return date_ach;
    }

    public int getStock() {
        return stock;
    }

    public int getQte_vente() {
        return qte_vente;
    }

    public int getQte_reste() {
        return qte_reste;
    }

    public float getPrix_Vente() {
        return Prix_Vente;
    }

    public float getPrix_Achat() {
        return Prix_Achat;
    }

    public float getGain() {
        return gain;
    }
    


}
