/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Les_classes;


import Mes_modeles.Client;

import Mes_modeles.Fournisseur;
import Mes_modeles.Piece;
import Mes_modeles.Stockk;
import Mes_modeles.Vente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Platform.exit;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author AmineGasa
 */
public class ConnectDB {

    private final String User = "root";
    private final String password = "";
    String ipLocal = "localhost";

    private String url = "jdbc:mysql://" + ipLocal + ":3306/gestion de produit";
    private Connection cnx;
    private Statement st, jt;
    private ResultSet rst;

    
    // Tout les fonction de gestion :
    public void DeleteAllElementTab(JTable T, int column, int row) {
        int i = 0;
        int j = 0;
        while (i < row) {
            while (j <= column) {
                T.setValueAt("", i, j);
                j++;
            }
            j = 0;
            i++;
        }

        }

    public String showDate() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(" YYYY-MM-dd");
        return sdf.format(d);

    }

    public String showDateTime() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
        return sdf.format(d);

    }

    public void ConnexionIntoDataBase() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver OK");
            try {
                cnx = DriverManager.getConnection(url, User, password);
                System.out.println("successful connexion");
            } catch (SQLException ex) {
                Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, " erreur connexion activer le serveur ou verifier "
                        + "\nle configuration de  serveur");

            } finally {
                
                
                
                
                exit();
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertPiece(Piece pc) {
        try {
            st = cnx.createStatement();
            String sqll = "INSERT INTO `piece`( `Nom_Commercial`, `N_Lot`, `Qte`, `PrixAchat`, `SHP`, `TotalAchat`, `Code_Barre`,`tva`) "
                    + "VALUES ('" + pc.Nom_Commercial + "','" + pc.N_Lot + "','" + pc.Qte + "','" + pc.PrixAchat  + "','" + pc.SHP + "','"+ pc.TotalAchat + "','" + pc.Code_Barre + "','"+ pc.tva + "') ";
            st.executeUpdate(sqll);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ereur operation");
            exit();
        }
    }
  
    public void AllPiece(JTable T) {
        try {
            st = cnx.createStatement();
            String sql = "select * from piece";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {
                j = 0;
                T.setValueAt(rst.getString("N_piece").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Nom_Commercial").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("N_Lot").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Qte").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("PrixAchat").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("SHP").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("TotalAchat").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Code_Barre").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("tva").toString(), i, j);
                j++;

                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }

    public void DeletePiece(int id) {
        String sql = "DELETE FROM piece WHERE N_piece=" + id;
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdatPiece(int id , Piece pc) {

        try { st = cnx.createStatement();
            String sql = "UPDATE piece SET Nom_Commercial='" + pc.Nom_Commercial + "',N_Lot='" + pc.N_Lot + "',"
                    + "Qte='" + pc.Qte + "',PrixAchat='" + pc.PrixAchat  + "',SHP='" + pc.SHP +"',TotalAchat='" + pc.TotalAchat + 
                    "',Code_Barre='" + pc.Code_Barre + "',tva='" + pc.tva + "'"
                    + "where N_piece=" + id ;
           
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void FindPiece(JTable T, String word, String recherche) {
        try {
            st = cnx.createStatement();
            String sql = "SELECT * FROM piece WHERE " + word + " like '" + recherche + "%'  ";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {            
                j = 0;
                T.setValueAt(rst.getString("N_piece").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Nom_Commercial").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("N_Lot").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Qte").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("PrixAchat").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("SHP").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("TotalAchat").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Code_Barre").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("tva").toString(), i, j);
                j++;

                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void FindNomCommercial(JComboBox combo) {
        try {
            st = cnx.createStatement();
            String sql = "select Nom_Commercial  from piece ";
            rst = (ResultSet) st.executeQuery(sql);
            ArrayList<String> ar = new ArrayList<>();
            ArrayList<String> rpl = new ArrayList<>();
            while (rst.next()) {
                ar.add(rst.getString("Nom_Commercial").toString());

            }
            rpl = Rplace(ar);
            for (int i = 0; i < rpl.size(); i++) {
                combo.addItem(rpl.get(i));
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }

    }
    
    ArrayList<String> Rplace(ArrayList<String> ar) {
        ArrayList<String> rpl = new ArrayList<>();
        int K = 0;
        boolean test;
        while (K < ar.size()) {
            test = true;
            for (int i = 0; i < rpl.size(); i++) {
                if (ar.get(K).equals(rpl.get(i))) {
                    test = false;
                }
            }
            if (test) {
                rpl.add(ar.get(K));
            }
            K++;
        }

        return rpl;
    }
    
    public void FindQteTotal(String sql, String sql1, JTextField jt) {
        try {
            st = cnx.prepareStatement(url);
            st = cnx.prepareStatement(sql);
            rst = st.executeQuery(sql);
            if (rst.next()) {

                String f = rst.getString(sql1);
                jt.setText(/*df.format(*/f/*)*/ + "");
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
                ArrayList<String> DES = new ArrayList<>();
    
    public void AllStock(JTable T) {

        try {
            ArrayList<Stockk> list = new ArrayList<Stockk>();
            st = cnx.createStatement();
            String sql = "select * from stock";
            rst = (ResultSet) st.executeQuery(sql);
            DES.clear();
            while (rst.next()) {

                Stockk ST = new Stockk(rst.getInt("N_prod"),rst.getString("Nom_Commercial"),
                        rst.getDate("date_ach") + "", rst.getInt("stock"),
                        rst.getInt("qte_vente"), rst.getFloat("Prix_Vente"),
                        rst.getFloat("Prix_Achat")
                );
                list.add(ST);
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[11];
            for (int k = 0; k < list.size(); k++) {
                row[0] = list.get(k).getN_prod();
                row[1] = list.get(k).getNom_Commercial();
                DES.add(list.get(k).getNom_Commercial());
                row[2] = list.get(k).getDate_ach();
                row[3] = df.format(list.get(k).getStock());
                row[4] = list.get(k).getQte_vente();
                row[5] = list.get(k).getQte_reste();
                row[6] = /*df.format(*/ list.get(k).getPrix_Achat()/*)*/;
                row[7] = list.get(k).getPrix_Vente();
                row[8] = list.get(k).getGain();

                mo.addRow(row);
            }
            list.clear();

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }

    public ArrayList<String> CONTROLE() {

        ArrayList<String> rpl = new ArrayList<>();
        ArrayList<String> rpl1 = new ArrayList<>();
        int K = 0;
        boolean test;
        while (K < DES.size()) {
            test = true;
            for (int i = 0; i < rpl.size(); i++) {
                if (DES.get(K).equals(rpl.get(i))) {
                    test = false;
                }
            }
            if (test) {
                rpl.add(DES.get(K));
            }
            if (test == false) {
                rpl1.add(DES.get(K));
            }
            K++;
        }

        return rpl1;
    }

    public void insertStock(Stockk ST ,int s) {

        try {
            System.out.println(ST.getNom_Commercial()+ " " + ST.getDate_ach() + " " + ST.getStock()
                    + " " + ST.getQte_vente() + " " + ST.getQte_reste() + " " + " " + ST.getPrix_Achat()
                    + " " + ST.getPrix_Vente()+ " " + ST.getGain());
            st = cnx.createStatement();
            String sql;
            if (s == 1) {
                sql = "INSERT INTO `stock`(`Nom_Commercial`, date_ach, `stock`, `qte_vente`, `qte_reste`, `Prix_Achat`, `Prix_Vente`, `gain`) "
                        + "VALUES ('" + ST.getNom_Commercial() + "' , '" + ST.getDate_ach() + "','" + ST.getStock() + "','" + ST.getQte_vente()+"','" + ST.getQte_reste() + "','" + ST.getPrix_Achat() + "','" + ST.getPrix_Vente() + "','" + ST.getGain() +"') ";
            } else {
                
                sql = "INSERT INTO `stock`(`Nom_Commercial`, `stock`, `qte_vente`, `qte_reste`, `Prix_Achat`, `Prix_Vente`, `gain`) "
                        + "VALUES ('" + ST.getNom_Commercial() + "' , '" +  ST.getStock() + "','" + ST.getQte_vente()+"','" + ST.getQte_reste() + "','" + ST.getPrix_Achat() + "','" + ST.getPrix_Vente() + "','" + ST.getGain() +"') ";
            }
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ereur operation");
            exit();
        }

    }

     public void DeleteStock(int id) {
        String sql = "DELETE FROM stock WHERE N_prod=" + id;
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdatStock(String sql) {

        try {

            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void FindStock(JTable T, String sql) {

        try {
            ArrayList<Stockk> list = new ArrayList<Stockk>();
            st = cnx.createStatement();

            rst = (ResultSet) st.executeQuery(sql);
            while (rst.next()) {

                Stockk ST = new Stockk(rst.getInt("N_prod"),rst.getString("Nom_Commercial"),
                        rst.getDate("date_ach") + "", rst.getInt("stock"),
                        rst.getInt("qte_vente"), rst.getFloat("Prix_Vente"),
                        rst.getFloat("Prix_Achat")
                );
                list.add(ST);
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[11];
            for (int k = 0; k < list.size(); k++) {
                
                row[0] = list.get(k).getN_prod();
                row[1] = list.get(k).getNom_Commercial();
                DES.add(list.get(k).getNom_Commercial());
                row[2] = list.get(k).getDate_ach();
                row[3] = df.format(list.get(k).getStock());
                row[4] = list.get(k).getQte_vente();
                row[5] = list.get(k).getQte_reste();
                row[6] = /*df.format(*/ list.get(k).getPrix_Achat()/*)*/;
                row[7] = list.get(k).getPrix_Vente();
                row[8] = list.get(k).getGain();

                mo.addRow(row);
            }
            list.clear();

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }

    public void AllStockVente(JTable T) {

        try {
            ArrayList<Stockk> list = new ArrayList<Stockk>();
            st = cnx.createStatement();
            String sql = "select N_prod,Nom_Commercial,stock,"
                    + " qte_vente,qte_reste,Prix_Vente,gain from stock ";
            rst = (ResultSet) st.executeQuery(sql);
            DES.clear();
            while (rst.next()) {

                Stockk ST = new Stockk(rst.getInt("N_prod"), rst.getString("Nom_Commercial"),
                        rst.getInt("stock"),
                        rst.getInt("qte_vente"), rst.getInt("qte_reste"),
                        rst.getFloat("Prix_Vente"), rst.getFloat("gain")
                );
            
            
                list.add(ST);
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[7];
            for (int k = 0; k < list.size(); k++) {
                row[0] = list.get(k).getN_prod();
                row[1] = list.get(k).getNom_Commercial();
                row[2] = df.format(list.get(k).getStock());
                row[3] = list.get(k).getQte_vente();
                row[4] = list.get(k).getQte_reste();
                row[5] = list.get(k).getPrix_Vente();
                row[6] = list.get(k).getGain();

                mo.addRow(row);
            }
            list.clear();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void AllStockVenteRcherche(JTable T, String S) {

        try {
            ArrayList<Stockk> list = new ArrayList<Stockk>();
            st = cnx.createStatement();
            String sql = "select N_prod,Nom_Commercial,stock,"
                    + " qte_vente,qte_reste,Prix_Vente,gain from stock where "
                    + "Nom_Commercial like '" + S + "%'";
            rst = (ResultSet) st.executeQuery(sql);
            DES.clear();
            while (rst.next()) {

                Stockk ST = new Stockk(rst.getInt("N_prod"), rst.getString("Nom_Commercial"),
                        rst.getInt("stock"),
                        rst.getInt("qte_vente"), rst.getInt("qte_reste"),
                        rst.getFloat("prix_vente"), rst.getFloat("gain")
                );
            
            
                list.add(ST);
            
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[7];
            for (int k = 0; k < list.size(); k++) {
                row[0] = list.get(k).getN_prod();
                row[1] = list.get(k).getNom_Commercial();
                row[2] = df.format(list.get(k).getStock());
                row[3] = list.get(k).getQte_vente();
                row[4] = list.get(k).getQte_reste();
                row[5] = list.get(k).getPrix_Vente();
                row[6] = list.get(k).getGain();

                mo.addRow(row);
            }
            list.clear();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }

    public void UpdateQteResteMinus( int id,int qte) {
        try {
            st = cnx.prepareStatement(url);
            String sql = "SELECT stock,qte_vente FROM `stock` WHERE N_prod = " + id + "  ";
            st = cnx.prepareStatement(sql);
            rst = st.executeQuery(sql);
            if (rst.next()) {
                int totale = rst.getInt("stock");
                int vente = rst.getInt("qte_vente")+qte;
                
                String sql2 = "Update stock set qte_vente='" + vente + "',qte_reste='" 
                        + (totale-vente) + "'"
                    + "where N_prod="+id;

            st.executeUpdate(sql2);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
       
    public void UpdateQteResteAdd( String des,int qte) {
        try {
            st = cnx.prepareStatement(url);
            String sql = "select stock,qte_vente,qte_reste,Nom_Commercial FROM `stock` WHERE Nom_Commercial = '" + des + "'  ";
            st = cnx.prepareStatement(sql);
            rst = st.executeQuery(sql);
            if (rst.next()) {
                int vente = rst.getInt("qte_vente")-qte;
                int reste = rst.getInt("qte_reste")+qte;
                
                String sql2 = "Update stock set qte_vente='" + vente + "',qte_reste='" 
                        + reste + "'"
                    + "where Nom_Commercial='"+des+"'";

            st.executeUpdate(sql2);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    } 
       
    public void insertClient(Client cl) {
        try {
            st = cnx.createStatement();
            String sql1 = "INSERT INTO `cl`( `nom_prenom`, `telephone`, `adresse`) "
                    + "VALUES ('" + cl.nom_prenom + "'," + "'" + cl.telephone + "','" + cl.adresse + "') ";
            st.executeUpdate(sql1);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erreur d'operation");
            exit();
        }
    }
    
    public void AllClient(JTable T) {
        try {
            st = cnx.createStatement();
            String sql = "select * from cl";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {
                j = 0;
                T.setValueAt(rst.getInt("id"), i, j);
                j++;
                T.setValueAt(rst.getString("nom_prenom").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("telephone").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("adresse").toString(), i, j);
                j++;
                

                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
        
    public void DeleteClient(int id) {
        String sql = "DELETE FROM cl WHERE id=" + id;
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdatClient(int id, Client cl) {

        try { st = cnx.createStatement();
            String sql = "Update cl set  nom_prenom='" + cl.nom_prenom + "',telephone='" + cl.telephone + "',"
                    + "adresse='" + cl.adresse + "'"
                    + "where id=" + id;
           
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void FindClient(JTable T, String word) {
        try {
            st = cnx.createStatement();
            String sql = "SELECT * FROM `cl` WHERE nom_prenom like '" + word + "%'  ";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {
                j = 0;
                T.setValueAt(rst.getInt("id"), i, j);
                j++;
                T.setValueAt(rst.getString("nom_prenom").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("telephone").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("adresse").toString(), i, j);
                j++;

                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " Erreur de recuperitaion");
        }
    }

    public void insertFournisseur(Fournisseur forn) {

        try {
            st = cnx.createStatement();
            String sql1 = "INSERT INTO `fournisseur`( `nom_prenom`, `telephone`, `adresse`,`ville`) "
                    + "VALUES ('" + forn.nom_prenom + "'," + "'" + forn.telephone + "','" + forn.adresse + "','" + forn.ville + "') ";
            st.executeUpdate(sql1);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ereur operation");
            exit();
        }

    }
    
    public void AllFournisseur(JTable T) {
        try {
            st = cnx.createStatement();
            String sql = "select * from fournisseur";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;

            while (rst.next()) {
                j = 0;
                T.setValueAt(rst.getInt("id"), i, j);
                j++;
                T.setValueAt(rst.getString("nom_prenom").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("telephone").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("adresse").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("ville").toString(), i, j);
                j++;
                i++;

            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void DeleteFourn(int id) {
        String sql = "DELETE FROM fournisseur WHERE id=" + id;
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdatFourn(int id, Fournisseur fr) {

        try { st = cnx.createStatement();
            String sql = "Update fournisseur set nom_prenom='" + fr.nom_prenom + "',telephone='" + fr.telephone + "',"
                    + "adresse='" + fr.adresse + "'" + ",ville='" + fr.ville + "'"
                    + " where id=" + id;
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void FindFournisseur(JTable T, String word, String recherche) {
        try {
            st = cnx.createStatement();
            String sql = "SELECT * FROM fournisseur WHERE " + word + " like '" + recherche + "%'  ";
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {
                j = 0;
                T.setValueAt(rst.getInt("id"), i, j);
                j++;
                T.setValueAt(rst.getString("nom_prenom").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("telephone").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("adresse").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("ville").toString(), i, j);
                j++;
                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void FindNomPrenomFournis(JComboBox combo) {
        try {
            st = cnx.createStatement();
            String sql = "select nom_prenom  from fournisseur";
            rst = (ResultSet) st.executeQuery(sql);
            ArrayList<String> ar = new ArrayList<>();
            ArrayList<String> rpl = new ArrayList<>();

            while (rst.next()) {

                ar.add(rst.getString("nom_prenom").toString());
            }
            rpl = Rplace(ar);
            for (int i = 0; i < rpl.size(); i++) {
                combo.addItem(rpl.get(i));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }

    }

    public void insertVente(Vente V) {

        try {
            st = cnx.createStatement();
            String sql1 = "INSERT INTO vente( nom_prenom, commentaire, marchendise,prix_a_payez,benefice,date_vente) "
                    + "VALUES ('" + V.getNom_prenom() + "'," + "'" + V.getCommentaire() + "','" + V.getMarchendise() + "','" + V.getPrix_a_payez()
                    + "','"+V.getBenefice()+"','"+V.getDate()+"')";
            st.executeUpdate(sql1);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ereur operation");
            exit();
        }

    }
    
    public void AllVente(JTable T) {

        try {
            ArrayList<Vente> list = new ArrayList<Vente>();
            st = cnx.createStatement();
            String sql = "select * from vente";
            rst = (ResultSet) st.executeQuery(sql);
            
            while (rst.next()) {
                String s="";s= rst.getDate("date_vente")+""+" " +rst.getTime("date_vente")+""; 
                Vente V = new Vente(rst.getInt("N_vente"), rst.getString("nom_prenom"),
                        rst.getString("commentaire"), rst.getString("marchendise"),
                         rst.getFloat("prix_a_payez"),rst.getFloat("benefice"),
                  s  );
                list.add(V);
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[7];
            for (int k = 0; k < list.size(); k++) {
                row[0] = list.get(k).getN_vente();
                row[1] = list.get(k).getNom_prenom();
               
                row[2] = list.get(k).getCommentaire();
                row[3] = list.get(k).getMarchendise();
             
                row[4] = df.format(list.get(k).getPrix_a_payez());
                row[5] = df.format(list.get(k).getBenefice());
                row[6] = /*df.format(*/ list.get(k).getDate()/*)*/;
                

                mo.addRow(row);
            }
           // list.clear();

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void FindVente(JTable T,String sql,JLabel j1,JLabel j2) {

        try {
            ArrayList<Vente> list = new ArrayList<Vente>();
            st = cnx.createStatement();
            
            rst = (ResultSet) st.executeQuery(sql);
           float prix=0,benefice=0;int client =0;
            while (rst.next()) {
                String s="";s= rst.getDate("date_vente")+""+" " +rst.getTime("date_vente")+""; 
                Vente V = new Vente(rst.getInt("N_vente"), rst.getString("nom_prenom"),
                        rst.getString("commentaire"), rst.getString("marchendise"),
                         rst.getFloat("prix_a_payez"),rst.getFloat("benefice"),
                  s  );
                prix=prix+rst.getFloat("prix_a_payez");
                benefice=rst.getFloat("benefice")+benefice;
                client++;        
                list.add(V);
            }

            DefaultTableModel mo = (DefaultTableModel) T.getModel();
            mo.setRowCount(0);
            DecimalFormat df = new DecimalFormat("0.00");
            Object row[] = new Object[7];
            for (int k = 0; k < list.size(); k++) {
                row[0] = list.get(k).getN_vente();
                row[1] = list.get(k).getNom_prenom();
               
                row[2] = list.get(k).getCommentaire();
                row[3] = list.get(k).getMarchendise();
             
                row[4] = df.format(list.get(k).getPrix_a_payez());
                row[5] = df.format(list.get(k).getBenefice());
                row[6] = /*df.format(*/ list.get(k).getDate()/*)*/;
                

                mo.addRow(row);
            }
           j1.setText("Total Vendu: "+prix);
            j2.setText("Gain Total: "+benefice+" Nombre de clients: "+client);

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
    
    public void UpdatVente(int id, String s) {

        try {
            String sql = "Update vente set commentaire='" +s + "'"
                    
                    + " where  	N_vente=" + id;
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public void findrupture(JTable T1){
        try {
            String sql = "SELECT * FROM stock WHERE qte_reste=0";
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void DeleteVente(int id) {
        String sql = "DELETE FROM vente WHERE  	N_vente=" + id;
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void FindNomPrenomClient(JComboBox combo) {
        try {
            st = cnx.createStatement();
            String sql = "select nom_prenom  from cl";
            rst = (ResultSet) st.executeQuery(sql);
            ArrayList<String> ar = new ArrayList<>();
            ArrayList<String> rpl = new ArrayList<>();

            while (rst.next()) {

                ar.add(rst.getString("nom_prenom").toString());
            }
            rpl = Rplace(ar);
            for (int i = 0; i < rpl.size(); i++) {
                combo.addItem(rpl.get(i));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }

    }
    
    public void StockEnRupture(JTable T){
        try {
            st = cnx.createStatement();
            String sql = "SELECT N_prod,Nom_Commercial,date_ach,stock,qte_reste FROM stock WHERE qte_reste=0" ;
            rst = (ResultSet) st.executeQuery(sql);
            int i = 0, j;
            while (rst.next()) {            
                j = 0;
                T.setValueAt(rst.getString("N_prod").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("Nom_Commercial").toString(), i, j);
                
                T.setValueAt(rst.getString("date_ach").toString(), i, j);
                j++;
                T.setValueAt(rst.getString("stock").toString(), i, j);
                j++;
             
                i++;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex + " error in recuperitaion");
        }
    }
}


    


